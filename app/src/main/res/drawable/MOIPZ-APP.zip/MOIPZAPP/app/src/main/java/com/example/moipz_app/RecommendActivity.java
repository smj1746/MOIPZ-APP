package com.example.moipz_app;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
public class RecommendActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7_ai_recommend);
    }
}